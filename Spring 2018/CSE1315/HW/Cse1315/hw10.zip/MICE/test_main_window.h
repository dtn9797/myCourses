bool test_main_window ();
