#include "owner.h"

std::string Owner::type () {return "Owner";}
