#include "emporium.h"
#include "scoop.h"
#include "test_emporium.h"
bool test_emporium () {
  Emporium em;
  //auto add items
  em.auto_add();
  //need to write test for emporium
  std::string expected = "";
  bool passed = true; // Optimist!

  //
  // Test constructor
  //
 // if (em.serving)
   
  return true;
}
