#include "manager.h"

    std::string Manager::type()  { return "Manager";}

    double Manager::get_hour_salary() const {return hour_salary;}
