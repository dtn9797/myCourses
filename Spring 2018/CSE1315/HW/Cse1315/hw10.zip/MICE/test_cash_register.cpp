#include <iostream>
#include "test_cash_register.h"
#include "cash_register.h"
#include "server.h"

bool test_cash_register() {
  std::string expected = "";
  bool passed = true; // Optimist!

  //
  // Test constructor
  //
  Cash_register c(2000);
  if (c.get_amount()!=2000){
    std::cerr << "Cash register Constructor failed !" << std::endl;
    passed = false;
  }

  //
  // Test operator overflow
  //

  Server server("Duy",1,100);

  c-=server;
  if (c.get_amount()!=1900){
    std::cerr << "Cash register -= overflow failed !" << std::endl;
    passed = false;
  }


  return true;


}
