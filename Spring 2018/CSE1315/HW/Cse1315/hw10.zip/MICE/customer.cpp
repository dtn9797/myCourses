#include "customer.h"

std::string Customer::type() {return "Customer";}

std::string Customer::get_phone_num() const {return phone_num;}
