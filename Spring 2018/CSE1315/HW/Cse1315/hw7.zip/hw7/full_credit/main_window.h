#ifndef MAIN_WINDOW_H
#define MAIN_WINDOW_H

#include <gtkmm.h>
#include "controller.h"
#include "library.h"

class Main_window : public Gtk::Window
{
    public:
        Main_window(Controller *con);
        virtual ~Main_window();
    protected:
        void on_list_pub_click();         
        void on_add_pub_click();         
        void on_checkout_pub_click();         
        void on_checkin_pub_click();
        void on_list_patron_click();         
        void on_add_patron_click(); 
        void on_help_click();           // Display help dialog
        void on_quit_click();            // Exit the game
    private:
       Controller *controller;



        //void set_sticks();                    // Update display, robot move
        //Nim *nim;                             // Current game board

        //Gtk::Label *sticks;                   // Display of sticks on game board
        //Gtk::Label *msg;                      // Status message display
        //Gtk::ToolButton *button1;             // Button to select 1 stick
       // Gtk::Image *button1_on_image;         //   Image when active
        //Gtk::Image *button1_off_image;        //   Image when inactive
        //Gtk::ToolButton *button2;             // Button to select 2 sticks
        //Gtk::Image *button2_on_image;
        //Gtk::Image *button2_off_image;
        //Gtk::ToolButton *button3;             // Button to select 3 sticks
        //Gtk::Image *button3_on_image;
        //Gtk::Image *button3_off_image;
        //Gtk::ToggleToolButton *computer_player;  // Button to enable robot
};
#endif 

