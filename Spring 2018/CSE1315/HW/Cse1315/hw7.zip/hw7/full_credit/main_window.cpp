#include "main_window.h"

Main_window::Main_window(Controller *con) {

    // /////////////////
    // G U I   S E T U P
    // /////////////////
     
    controller=con;

    set_default_size(400, 200);

    // Put a vertical box container as the Window contents
    Gtk::Box *vbox = Gtk::manage(new Gtk::Box(Gtk::ORIENTATION_VERTICAL, 0));
    add(*vbox);

    // ///////
    // M E N U
    // Add a menu bar as the top item in the vertical box
    Gtk::MenuBar *menubar = Gtk::manage(new Gtk::MenuBar());
    vbox->pack_start(*menubar, Gtk::PACK_SHRINK, 0);

    //     F I L E
    // Create a File menu and add to the menu bar
    Gtk::MenuItem *menuitem_file = Gtk::manage(new Gtk::MenuItem("_File", true));
    menubar->append(*menuitem_file);
    Gtk::Menu *filemenu = Gtk::manage(new Gtk::Menu());
    menuitem_file->set_submenu(*filemenu);


    //         Q U I T
    // Append Quit to the File menu
    Gtk::MenuItem *menuitem_quit = Gtk::manage(new Gtk::MenuItem("_Quit", true));
    menuitem_quit->signal_activate().connect(sigc::mem_fun(*this, &Main_window::on_quit_click));
    filemenu->append(*menuitem_quit);

    //    PUBLICATION
    // Create a publication menu and add to the menu bar
    Gtk::MenuItem *menuitem_publication = Gtk::manage(new Gtk::MenuItem("_Publication",true));
    menubar->append(*menuitem_publication);
    Gtk::Menu *publicationmenu = Gtk::manage(new Gtk::Menu());
    menuitem_publication->set_submenu(*publicationmenu);

    //  List
    Gtk::MenuItem *menuitem_list_pub = Gtk::manage(new Gtk::MenuItem("_List",true));
    menuitem_list_pub->signal_activate().connect(sigc::mem_fun(*this,&Main_window::on_list_pub_click));
    publicationmenu->append(*menuitem_list_pub);

    //  Add
    Gtk::MenuItem *menuitem_add_pub = Gtk::manage(new Gtk::MenuItem("_Add",true));
    menuitem_add_pub->signal_activate().connect(sigc::mem_fun(*this,&Main_window::on_add_pub_click));
    publicationmenu->append(*menuitem_add_pub);
    //  Checkout
    Gtk::MenuItem *menuitem_checkout_pub = Gtk::manage(new Gtk::MenuItem("_Check Out",true));
    menuitem_checkout_pub->signal_activate().connect(sigc::mem_fun(*this,&Main_window::on_checkout_pub_click));
    publicationmenu->append(*menuitem_checkout_pub);
    //  Checkin
    Gtk::MenuItem *menuitem_checkin_pub = Gtk::manage(new Gtk::MenuItem("_Check In",true));
    menuitem_checkin_pub->signal_activate().connect(sigc::mem_fun(*this,&Main_window::on_checkin_pub_click));
    publicationmenu->append(*menuitem_checkin_pub);

    // PATRON
    //Create a patron menu and add to the menu bar
    Gtk::MenuItem *menuitem_patron = Gtk::manage(new Gtk::MenuItem("_Patron",true));
    menubar->append(*menuitem_patron);
    Gtk::Menu *patronmenu = Gtk::manage(new Gtk::Menu());
    menuitem_patron->set_submenu(*patronmenu);

    // List
    Gtk::MenuItem *menuitem_list_patron = Gtk::manage(new Gtk::MenuItem("_List",true));
    menuitem_list_patron->signal_activate().connect(sigc::mem_fun(*this,&Main_window::on_list_patron_click));
    patronmenu->append(*menuitem_list_patron);

    // Add
    Gtk::MenuItem *menuitem_add_patron = Gtk::manage(new Gtk::MenuItem("_Add",true));
    menuitem_add_patron->signal_activate().connect(sigc::mem_fun(*this,&Main_window::on_add_patron_click));
    patronmenu->append(*menuitem_add_patron);

    //     H E L P
    // Create a Help menu and add to the menu bar
    Gtk::MenuItem *menuitem_help = Gtk::manage(new Gtk::MenuItem("_Help", true));
    menubar->append(*menuitem_help);
    Gtk::Menu *helpmenu = Gtk::manage(new Gtk::Menu());
    menuitem_help->set_submenu(*helpmenu);

    Gtk::MenuItem *menuitem_help0 = Gtk::manage(new Gtk::MenuItem("_Help", true));
    menuitem_help0->signal_activate().connect(sigc::mem_fun(*this,&Main_window::on_help_click));
    helpmenu->append(*menuitem_help0);


    // Make the box and everything in it visible
    vbox->show_all();

    // Start a new game
    //on_new_game_click();
}

Main_window::~Main_window() { }

// /////////////////
// C A L L B A C K S
// /////////////////

void Main_window::on_list_pub_click() { 
   controller->execute_cmd(2);
}

void Main_window::on_add_pub_click() {
    controller->execute_cmd(1);
}

void Main_window::on_checkout_pub_click() {
    controller->execute_cmd(3);
}

void Main_window::on_checkin_pub_click() {
    controller->execute_cmd(4);
}

void Main_window::on_list_patron_click() {
    controller->execute_cmd(6);
}

void Main_window::on_add_patron_click() {
    controller->execute_cmd(5);
}

void Main_window::on_quit_click() {
    hide();
}

void Main_window::on_help_click() {
    //Glib::ustring s = "<span size='24000' weight='bold'>Nim</span>\n<span size='large'>Copyright 2017 by George F. Rice</span>\n<span size='small'>Licensed under Creative Commons Attribution 4.0 International\nRobot icon created by Freepik, used under free attribution license</span>";
    //Gtk::MessageDialog dlg(*this, s, true, Gtk::MESSAGE_INFO, Gtk::BUTTONS_OK, true);
    //dlg.run();
   controller->execute_cmd(9);
}

// /////////////////
// U T I L I T I E S
// /////////////////

