#include "main_window.h"
#include <gtkmm.h>
#include "controller.h"
#include "library.h"

int main(int argc, char *argv[]) {
  //Gtk::Main kit(argc, argv);
  auto app = Gtk::Application::create(argc,argv,"edu.uta.cse1325.library");
  Library library;
  Controller controller(library);
  Main_window win(&controller);
  //controller.cli();
  return app->run(win);
}
