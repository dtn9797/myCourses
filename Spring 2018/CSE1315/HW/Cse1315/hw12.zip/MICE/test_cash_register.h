bool test_cash_register();
