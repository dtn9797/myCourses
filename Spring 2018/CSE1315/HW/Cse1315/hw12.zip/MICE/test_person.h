bool test_person();
