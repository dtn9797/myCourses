bool test_view();
