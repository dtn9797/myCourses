bool test_emporium ();
