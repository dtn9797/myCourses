bool test_customer ();
