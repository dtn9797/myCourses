#include "manager.h"

void Manager::create_scoop () {
 
  items.add_scoop(new Scoop("Vanilla","Favorite of Manager",.5,1,11,"Vanilla"));
}
