#include "test_main_window.h"

bool test_main_window () {
  return true;
}
