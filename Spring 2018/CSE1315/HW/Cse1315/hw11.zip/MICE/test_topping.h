bool test_topping();
