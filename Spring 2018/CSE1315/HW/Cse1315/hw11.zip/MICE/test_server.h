bool test_server();
