bool test_scoop();
