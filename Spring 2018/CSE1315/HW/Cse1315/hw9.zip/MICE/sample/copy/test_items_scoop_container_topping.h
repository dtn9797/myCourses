bool test_items_scoop_container_topping();
