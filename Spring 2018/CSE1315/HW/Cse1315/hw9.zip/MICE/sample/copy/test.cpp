
#include "test_items_scoop_container_topping.h"
#include <iostream>

int main() {
  if (!(test_items_scoop_container_topping()))
    std::cerr << "fail" << std::endl;
} 
