 #include "patron.h"

 string Patron::to_string() {return name + " (" + number + ")";}

 string Patron::get_patron_name() {return name;}
 string Patron::get_patron_phone_number() {return number;}

