#include "controller.h"
#include "view.h"
#include "library.h"
#include "publication.h"
#include "patron.h"
#include "genre.h"
#include "media.h"
#include "age.h"
#include <iostream>
#include <string>

using namespace std;

void Controller::cli() {
  int cmd = view.select_from_menu() ;
  while (cmd != 0) {
    execute_cmd(cmd);
    cmd = view.select_from_menu();
  }
}

void Controller::execute_cmd(int cmd) {
  if (cmd == 1) { // Add publication
    string title, author, copyright, isbn;
    int genre, media, age;

    title = Dialogs::input_string("Title?");

    author = Dialogs::input_string("Author?");

    copyright = Dialogs::input_string("Copyright date?");
    
    genre=view.select_genres();

    media = view.select_medias();

    age = view.select_ages();
    
    isbn=Dialogs::input_string("ISBN?");

    library.add_publication(Publication(title, author, copyright, genre, media, age, isbn));

 } else if (cmd == 2) { // List all publications
    view.list_publications();

 } else if (cmd == 3) { // Check out publication
    int pub, pat;

    pub = view.select_publications();

    pat = view.select_patrons();

    try {
      library.check_out(pub, pat);
    } catch (Publication::Invalid_transaction e) {
      Dialogs::message( "ERROR: That publication is already checked out!");
    }
    
 } else if (cmd == 4) { // Check in publication
    int pub;

    pub = view.select_publications();

    try {
      library.check_in(pub);
    } catch (Publication::Invalid_transaction e) {
      Dialogs::message( "ERROR: That publication is already checked in!");
    }

 } else if (cmd == 5) { // Add patron
    string name, number;

    name = Dialogs::input_string("Patrons?");

    number = Dialogs::input_string("Phone Number?");

    library.add_patron(Patron(name, number));
    
 } else if (cmd == 6) { // List all patrons
    view.list_patrons();

 } else if (cmd == 9) { // Help
    view.help();
 } else if (cmd == 0) { // Exit
 } else if (cmd == 99) { // Easter Egg
   library.easter_egg();
 } else {
   cerr << "**** Invalid command - type 9 for help" << endl << endl;
 }
}

