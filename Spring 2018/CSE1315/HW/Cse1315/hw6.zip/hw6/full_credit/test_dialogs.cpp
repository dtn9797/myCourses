#include "dialogs.h"
#include <iostream>
#include <gtkmm.h>
#include <vector>

int main (int argc, char *argv[] ){
  Gtk::Main kit (argc,argv);
  std::vector<int> limit{1,2,3,4,5,6,0,9,99} ;
  int test_output = Dialogs::input ("Testing. The text field only accpets 1->6, 0,9, and 99. It will show errors otherwise.",limit);
  std::cout <<"Success:"<< test_output << "\n";

  std::string test_output_string= Dialogs::input_string ("Title?");
  std::cout<<"Sucess:"<< test_output_string << "\n";
  return 0;
}
