#ifndef __VIEW_H
#define __VIEW_H 201609
 
#include "library.h"
#include "dialogs.h"
#include <string>


class View {
  public:
    View(Library& lib) : library(lib) { }
    int select_from_menu();
    string get_publications();
    void list_publications();
    int select_publications();
    int select_medias();
    int select_ages();
    int select_genres();
    int select_patrons();
    void list_patrons();
    void help();
  private:
    Library& library; 
};
#endif
