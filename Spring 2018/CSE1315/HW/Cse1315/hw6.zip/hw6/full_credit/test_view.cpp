#include "view.h"
#include "patron.h"
#include "publication.h"
#include "library.h"
#include <iostream>
#include <string>
using namespace std;

int main() {
  Library library;
  View view(library);

  bool passed = true;

  //
  // Set up library
  //
  Patron larry("Larry", "817-555-1111");
  Patron curly("Curly", "817-555-2222");
  Patron moe("Moe", "817-555-3333");

  library.add_patron(larry);
  library.add_patron(curly);
  library.add_patron(moe);

  Publication foundation("Foundation", "Isaac Asimov", "1942", 
      Genre::fiction, Media::book, Age::adult, "0385177259");
  Publication foundation_empire("Foundation and Empire", "Isaac Asimov", "1943", 
      Genre::fiction, Media::book, Age::adult, "0385177259");
  Publication foundation2("Second Foundation", "Isaac Asimov", "1944", 
      Genre::fiction, Media::book, Age::adult, "0385177259");
  Publication war("War of the Worlds", "Jeff Wayne", "1977",
      Genre::performance, Media::audio, Age::teen, "9780711969148");
  Publication wonka("Willy Wonka and the Chocolate Factory", "Roald Dahl", "1971",
      Genre::performance, Media::video, Age::children, "0142410314");

  library.add_publication(foundation);
  library.add_publication(foundation_empire);
  library.add_publication(foundation2);
  library.add_publication(war);
  library.add_publication(wonka);

  library.check_out(2, 1);

  int int_output;
  string string_output;
  //
  // Test menu
  //
  cout << "Test menu" << endl;
  int_output = view.select_from_menu();
  cout<<"Success:"<<to_string(int_output)<<endl;
  //
  // Test list publications
  //
  cout << "Test list publications" << endl;
  view.list_publications();
  //
  // Test select medias
  //
  cout << "Test select medias" << endl;
  int_output=view.select_medias();
  cout<<"Success:"<<to_string(int_output)<<endl;
   //
  // Test select ages
  //
  cout << "Test select ages" << endl;
  int_output=view.select_ages();
  cout<<"Success:"<<to_string(int_output)<<endl;
   //
  // Test select genres
  //
  cout << "Test select genres" << endl;
  int_output=view.select_genres();
  cout<<"Success:"<<to_string(int_output)<<endl;
  //
  // Test select publications
  //
  cout << "Test select publications" << endl;
  int_output=view.select_publications();
  cout<<"Success:"<<to_string(int_output)<<endl;
  //
  // Test list patrons
  //
  cout << "Test list patrons" << endl;
  view.list_patrons();

  //
  // Show results
  //
  cout << endl << "Verify output for pass or fail" << endl;
}
