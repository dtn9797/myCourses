#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

// A function named "uniq", which returns accepts a vector of SORTED strings
// and also returns a (different) vector of strings in which all duplicates
// of the original vector have been removed. 

vector<string> uniq(vector<string> original) {

    // The result vector, short for "new strings"

    vector<string> news = { }; 

    // If the original vector was empty (an "edge case" we must consider),
    // then we'll just return the empty news vector.

    if (original.size() > 0) { 

        // Put the first string on our result vector - it can't be a duplicate

        news.push_back(original[0]);

        // Now work through the second through last string. If this string
        // isn't the same as the previous string, store it in the result vector.
        // If it is, it's a duplicate - ignore it!
        // Note that we can't use a for-each loop here, because we must skip 
        // the first string in vector.
        // Also note that, unlike C's char*, we CAN use == and != to compare strings.
        // The string class has explicitly defined what == and != means!
        // Classes ftw!

        for (int i=1; i<original.size(); ++i)  // note: not a range-for
             if(original[i-1] != original[i])
                 news.push_back(original[i]); 
    }

    // Return the result that we've built.

    return news;
}

// Read a bunch of strings into a vector of strings, sort them 
// into lexicographical order (alphabetical order), eliminate 
// any duplicate (non-unique) strings, and print the strings 
// from the vector to see what we have. 

int main() {

    // Create a vector to hold any number of strings that we want.

    vector<string> words;

    // Read in a bunch of words and store in vector "words".
    // Note the unusual 3-term for loop - very flexible construct, isn't it?

    cout << "Enter words, followed by EOF (e.g., Control-d) or 'quit':" << endl;
    for (string s; cin>>s && s != "quit"; )  // && means AND
        words.push_back(s);

    // Now sort our "words" vector, and call our "uniq" function to eliminate duplicates.

    sort(words.begin(), words.end());        // sort the words we read
    words = uniq(words);                     // eliminate non-unique words

    // Finally, use a for-each loop to print all the unique words, one per line.

    for (string s : words) 
        cout << s << '\n';
}
