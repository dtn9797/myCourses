#include <iostream>
using namespace std;

// Complex_number models the complex number system, where each number includes
// both a real and imaginary part. This model only stores an imaginary number
// and converts it to a string. A complete model would need to define operators.

class Complex_number {
  public:
    Complex_number(double re, double im) : _re{re}, _im{im} { }
    string to_string() {
      return std::to_string(_re) + "+" +
             std::to_string(_im) + 'i';
    }
  private:
    double _re, _im;
};

// Very simple visual test for the Complex_number class.

int main() {
  Complex_number c{3,5};
  cout << c.to_string() << endl;
}

