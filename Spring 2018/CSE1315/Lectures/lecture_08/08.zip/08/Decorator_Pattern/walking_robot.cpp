#include "walking_robot.h"

void Walking_robot::announce() {
  cout << "Make way!" << endl;
}
