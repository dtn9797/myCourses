#ifndef __ROBOT_H
#define __ROBOT_H

#include <iostream>
using namespace std;

class Robot {
  public:
    virtual void announce() { }
};

#endif
