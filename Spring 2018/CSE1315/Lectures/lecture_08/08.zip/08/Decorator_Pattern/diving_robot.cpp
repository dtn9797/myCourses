#include "diving_robot.h"

void Diving_robot::announce() {
  cout << "Glub glub!" << endl;
}
