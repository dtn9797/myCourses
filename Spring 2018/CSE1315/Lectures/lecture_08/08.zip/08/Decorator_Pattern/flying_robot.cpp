#include "flying_robot.h"

void Flying_robot::announce() {
  cout << "Heads up!" << endl;
}
