 #include <iostream>
 #include <exception>
 #include <climits>
 using namespace std;

 class Bad_area: public exception { };

 int area(int length, int width) {  // calculate area of a rectangle
	// length and width must be positive
    if (length<=0 || width <=0) throw Bad_area{};
    return length*width;
 }

 int main() {
    int length1 = 14;
    int width1 = 10;

    cout << "Area of " << length1 << " x " << width1 << " is " << area(length1, width1) << endl;

    int length2 = INT_MAX;
    int width2 = 2;

    cout << "Area of " << length2 << " x " << width2 << " is " << area(length2, width2) << endl;
 }

