 #include <iostream>
 #include <exception>
 #include <stdexcept>
 using namespace std;

 class Bad_area: public exception { };

 int area(int length, int width) {  // calculate area of a rectangle
	// length and width must be positive
    if (length<=0 || width <=0) 
        throw Bad_area{};
    return length*width;
 }

 int main() {
    // TEST #1: Normal Sides
    if (area(14, 10) != 140) cerr << "FAIL: 10x14 not 140 but " << area(14,10) << endl;

    // TEST #2: Identical Length Sides
    if (area(10, 10) != 100) cerr << "FAIL: 10x10 not 100 but " << area(10,10) << endl;

    // TEST #3: Zero Length Side 
    if (area(0, 10) != 0) cerr << "FAIL: 0x10 not 0 but " << area(0,10) << endl;

    // TEST #4: Negative Length Side 
    try {
      int i = area(-1, -2);
      cerr << "FAIL: Negative side not exception but " << area(-1, -2) << endl;
    } catch (Bad_area e) {
    }
 }
