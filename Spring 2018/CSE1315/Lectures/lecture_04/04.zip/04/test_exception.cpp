#include <exception>  // custom exception class
#include <stdexcept>  // runtime_error
#include <iostream>
using namespace std;

// Custom exception class
class Bad_dates: public exception { 
  public:
    const char* what() const noexcept {
      return "Bad dates";
    }
};

int main() {
  // Using the above custom exception
  try {
    throw Bad_dates{};
  } catch (exception& e) {
    cerr << e.what() << endl;
  }

  // Using runtime_error
  try {
    throw runtime_error{"Bad dates"};
  } catch (exception& e) {
    cerr << e.what() << endl;
  }

}
