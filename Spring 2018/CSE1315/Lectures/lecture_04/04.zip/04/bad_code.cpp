int main() {
{
  String name;
  cin >> name;
  std:cout << “Hello, << name << ‘!’
  if (Name = ‘George’ cout << “ (prof)” << end1;
}; 
