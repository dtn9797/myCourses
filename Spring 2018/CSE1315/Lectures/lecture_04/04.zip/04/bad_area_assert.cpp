 #include <iostream>
 #include <cassert>
 using namespace std;

 int area(int length, int width) {
   // if (length<=0 || width<=0) throw Bad_area{ };  // The exception version
   assert (length>0 && width>0);
   int result = length*width;
   // if (result < 0) throw Bad_area { };            // The exception version
   assert (result > 0);
   return result;
 }
 int main() {
   cout << area(3, 5) << endl;
   cout << area(8, 2) << endl;
   cout << area(3,-5) << endl;
   return 0; // success
 }

