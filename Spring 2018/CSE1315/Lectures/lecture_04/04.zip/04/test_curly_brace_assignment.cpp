#include <iostream>
using namespace std;

int main() {
  int i{2};
  cout << i << endl;

  i{4}; // No, you CANNOT assign (rather than initialize) using curly braces
  cout << i << endl;

  int x{3};
  int y{4};
  i{x+y};
  cout << i << endl;
}
