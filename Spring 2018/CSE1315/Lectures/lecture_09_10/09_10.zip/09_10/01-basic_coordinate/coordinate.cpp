 #include "coordinate.h"

/**
 * Coordinate models a location on a 2D grid.
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
int Coordinate::get_x( ) {return _x;}
int Coordinate::get_y( ) {return _y;}

