#include "view.h"
#include <iostream>

/**
 * View displays the grid on a text terminal
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
void View::print_banner() {
    cout << "============" << endl
         << "ROVING ROBOT" << endl
         << "============" << endl << endl;
}

Grid View::get_grid() {return grid;}
void View::print_grid() {
  cout << endl;
  cout << grid.to_string() << endl;
};
 
