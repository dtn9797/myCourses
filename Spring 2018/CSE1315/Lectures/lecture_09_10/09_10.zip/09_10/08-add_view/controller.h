#include "robot.h"
#include "grid.h"
#include "view.h"

/**
 * Controller manages the model and view
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
class Controller {
  public:
    void cli();
    void execute_cmd(string cmd);
    View get_view();

  private:
    Robot _player;
    Grid _grid{_player};
    View _view{_grid};
};
 
