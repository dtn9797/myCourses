#include "globals.h"
#include "robot.h"
#include "grid.h"
#include <string>
#include <iostream>

using namespace std;

/**
 * Grid models a 2-dimensional grid of spaces containing a robot
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
int main() {
  string expected = ".........\n.........\n.........\n.........\n.........\n.....R...\n.........\n.........\n.........\n";
  string actual = "";
  Grid grid(Robot("Marvin", Coordinate(5, 5)));
  actual += grid.to_string( );

  if (expected != actual) {
    cerr << "fail: grid.h: static initialization" << endl;
    cerr << "expected: \"" << expected << "\"" << endl;
    cerr << "actual:   \"" << actual << "\"" << endl << endl;
    return -1;
  }

  srand(0xbadcafe);
  expected = ".........\n.........\n.........\n.........\n.........\n......R..\n.........\n.........\n.........\n";
  actual = "";
  grid = Grid{};
  actual += grid.to_string( );


  if (expected != actual) {
    cerr << "fail: grid.h: random initialization" << endl;
    cerr << "expected: \"" << expected << "\"" << endl;
    cerr << "actual:   \"" << actual << "\"" << endl << endl;
    return -1;
  }

}
