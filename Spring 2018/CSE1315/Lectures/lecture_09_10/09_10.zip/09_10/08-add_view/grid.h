#ifndef GRID
#define  GRID 2017

#include "robot.h"

/**
 * Grid models a 2-dimensional grid of spaces containing a robot
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
class Grid {
  public:
    Grid(Robot player) : _player{player} { }
    Grid() : Grid(Robot()) { }
    Robot get_player( );
    void move_player(Coordinate direction);
    string to_string();

  private:
    Robot _player; // The robot wandering the grid
};
#endif 
