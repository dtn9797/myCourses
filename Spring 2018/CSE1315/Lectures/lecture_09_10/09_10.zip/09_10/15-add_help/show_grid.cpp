#include "globals.h"
#include "robot.h"
#include "grid.h"
#include <string>
#include <iostream>

using namespace std;

/**
 * Grid models a 2-dimensional grid of spaces containing a robot
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
int main() {
  cout << "Grid at (5, 5)" << endl << endl;
  Grid grid(Robot("Marvin", Coordinate(5, 5)));
  cout << grid.to_string( ) << endl;

  cout << "Grid at random location" << endl << endl;
  grid = Grid{};
  cout << grid.to_string( ) << endl;

}
