#include "globals.h"
#include "robot.h"
#include "coordinate.h"
#include <iostream>

/**
 * Robot models a generic autonomous or remote controlled machine.
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */

 int main() {
  string expected = "Robot00 (0,0)  Robot02 (0,2)  Robot20 (2,0)  Robot22 (2,2)  ";
  string actual = "";
  for(int x = 0; x < 3; x += 2) {
    for(int y = 0; y < 3; y += 2) {
      Robot r("Robot" + std::to_string(x) + std::to_string(y), Coordinate(x, y));
      actual += r.to_string( ) + "  ";
    }
  }

  if (expected != actual) {
    cerr << "fail: robot.h: static initialization" << endl;
    cerr << "expected: \"" << expected << "\"" << endl;
    cerr << "actual:   \"" << actual << "\"" << endl << endl;
    return -1;
  }

  srand(0xbadcafe);
  expected = "Robot1 (5,6)  Robot2 (6,5)  Robot3 (8,7)  Robot4 (4,6)  Robot5 (4,5)  ";
  actual = "";
  for(int i = 0; i < 5; ++i) {
    Robot r;
    actual += r.to_string( ) + "  ";
  }

  if (expected != actual) {
    cerr << "fail: robot.h: random initialization" << endl;
    cerr << "expected: \"" << expected << "\"" << endl;
    cerr << "actual:   \"" << actual << "\"" << endl << endl;
    return -1;
  }

  expected = "Marvin (5,5)  Marvin (2,5)  Marvin (2,3)  Marvin (32,3)  Marvin (29,8)  ";
  actual = "";
  Robot r("Marvin", Coordinate(5, 5));  // "Marvin" starts at (5, 5)
  actual += r.to_string( ) + "  ";
  r.move(Coordinate(-3,0)); // Move "Marvin" left 3 spaces, to (2, 5)
  actual += r.to_string( ) + "  ";
  r.move(Coordinate(0,-2)); // Move "Marvin" up 2 spaces, to (2, 3)
  actual += r.to_string( ) + "  ";
  r.move(Coordinate(30,0)); // Move "Marvin" right 30 spaces, to (32, 3)
  actual += r.to_string( ) + "  ";
  r.move(Coordinate(-3,5)); // Move "Marvin" down and left, to (29, 8)
  actual += r.to_string( ) + "  ";

  if (actual != actual) {
    cerr << "fail: robot.h: movement" << endl;
    cerr << "expected: \"" << expected << "\"" << endl;
    cerr << "actual:   \"" << actual << "\"" << endl << endl;
    return -1;
  }

  return 0;
}

