#include <iostream>
using namespace std;

class Test {
  private:
    int i = 3;
  public:
    // Test(int i) : i{i} { }
    Test(int i) {i = i; }
    int get_i() {return i;};
};

int main() {
  Test t{5};
  cout << t.get_i() << endl;
}

