#include "controller.h"
#include <iostream>

using namespace std;

/**
 * Controller manages the model and view
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
int main() {
  Controller controller{ };
  controller.cli();
}
