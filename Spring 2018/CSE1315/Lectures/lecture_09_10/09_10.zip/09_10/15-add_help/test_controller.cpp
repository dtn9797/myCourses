#include "globals.h"
#include "controller.h"
#include "grid.h"
#include "robot.h"
#include "coordinate.h"
#include <iostream>
#include <vector>

/**
 * Controller manages the model and view
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
int main() {
  vector<string> tests;
  tests.push_back("4");
  tests.push_back("1");
  tests.push_back("2");
  tests.push_back("3");
  tests.push_back("6");
  tests.push_back("9");
  tests.push_back("8");
  tests.push_back("7");
                         

  cout << "=================" << endl
       << "ROVING ROBOT TEST" << endl
       << "=================" << endl << endl;

  Controller controller;
  controller.get_view().print_grid();
  for(int i=0; i<tests.size(); ++i) {
     cout << " Command? " << tests[i] << endl;
     controller.execute_cmd(tests[i]);
     controller.get_view().print_grid();
   }
}
