#include "controller.h"
#include "globals.h"
#include "grid.h"
#include <iostream>

/**
 * Controller manages the model and view
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
void Controller::cli() {
    cout << "============" << endl
         << "ROVING ROBOT" << endl
         << "============" << endl << endl;

    string cmd = "x";
    while (cmd[0] != '0') {
        cout << grid.get_player().get_coordinate().to_string() << " Command? ";
        cin >> cmd;
        execute_cmd(cmd);
        cout << grid.to_string() << endl;
    }
};
void Controller::execute_cmd(string cmd) {
        if (cmd[0] == '1') { grid.move_player(Coordinate(-1, 1)); }
        if (cmd[0] == '2') { grid.move_player(Coordinate( 0, 1)); }
        if (cmd[0] == '3') { grid.move_player(Coordinate( 1, 1)); }
        if (cmd[0] == '4') { grid.move_player(Coordinate(-1, 0)); }
        if (cmd[0] == '5') { grid.move_player(Coordinate( 0, 0)); }
        if (cmd[0] == '6') { grid.move_player(Coordinate( 1, 0)); }
        if (cmd[0] == '7') { grid.move_player(Coordinate(-1,-1)); }
        if (cmd[0] == '8') { grid.move_player(Coordinate( 0,-1)); }
        if (cmd[0] == '9') { grid.move_player(Coordinate( 1,-1)); }
};
