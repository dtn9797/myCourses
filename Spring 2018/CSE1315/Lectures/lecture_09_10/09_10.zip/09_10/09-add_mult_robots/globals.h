#ifndef GLOBALS 
#define  GLOBALS 2016

const int MAX_X = 29; // x is in range [0,MAX_X]
const int MAX_Y = 29; // y is in range [0,MAX_Y]

const int NUM_ROBOTS = 10; // number of robots in grid

#endif
