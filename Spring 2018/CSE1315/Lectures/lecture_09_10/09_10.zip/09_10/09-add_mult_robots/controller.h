#include "robot.h"
#include "grid.h"
#include "view.h"

/**
 * Controller manages the model and view
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
class Controller {
  public:
    void cli();
    void execute_cmd(string cmd);
    View get_view();

  private:
    Grid _grid{};
    View _view{_grid};
};
 
