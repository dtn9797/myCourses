#include "globals.h"
#include "robot.h"
#include "grid.h"
#include <string>
#include <iostream>

using namespace std;

/**
 * Grid models a 2-dimensional grid of spaces containing a robot
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */

enum Mode {generate_output, evaluate, error};

Mode mode = error;

void set_mode(int argc, char* argv[]) {
  if (argc == 1) {
    mode = evaluate;
  } else if ((argc == 2) && (string(argv[1]) == "-v")) {
      mode = generate_output;
  }
}
 
string get_expected(string test_description) {
  string result = "";
  string aline;
  for (int i=0; i < MAX_Y; ++i) {
     if (!getline(cin, aline)) {
       cerr << "ERROR: Insufficient expected lines for " << test_description << endl;
       exit(-2);
     }
     result += aline + '\n';
  }
  getline(cin, aline); // delete the separator \n
  return result;
}

void evaluate_test(string test_description, string actual) {
  if (mode == evaluate) {
    string expected = get_expected(test_description);

    if (expected != actual) {
      cerr << "fail: grid.h: " + test_description << endl;
      cerr << "expected: \"" << expected << "\"" << endl;
      cerr << "actual:   \"" << actual << "\"" << endl << endl;
      exit(-1);
    }
  } else if (mode == generate_output) {
      cout << actual << endl;
  } else {
      cerr << "ERROR: Invalid mode: " << mode << endl;
  }
}

int main(int argc, char* argv[]) {
  srand(0xbadcafe);
  set_mode(argc, argv);

  //
  // Test #1 - Default initialization
  //
  string actual;
  Grid grid{};
  actual = grid.to_string( );
  evaluate_test("Default initialization", actual);

  grid = Grid{33};
  actual = grid.to_string( );
  evaluate_test("Initialize to 33 robots", actual);

  grid = Grid{Coordinate{0, 0}};
  grid.move_player(Coordinate{-1, -1});
  actual = grid.to_string( );
  evaluate_test("Move off upper left of grid", actual);

  grid = Grid{Coordinate{MAX_X-1, MAX_Y-1}};
  grid.move_player(Coordinate{1, 1});
  actual = grid.to_string( );
  evaluate_test("Move off lower right of grid", actual);
}
