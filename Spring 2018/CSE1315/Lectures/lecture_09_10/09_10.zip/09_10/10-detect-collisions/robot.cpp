#include "robot.h"
#include "globals.h"
#include "coordinate.h"

using namespace std;

/**
 * Robot models a generic autonomous or remote controlled machine.
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
string Robot::get_robot_id( ) {return _robot_id;}
Coordinate Robot::get_coordinate( ) {return _coordinate;}
string Robot::to_string() {return _robot_id + ' ' +  _coordinate.to_string();}
void Robot::move(Coordinate direction) {
    _coordinate = Coordinate{_coordinate.get_x() + direction.get_x(), 
                             _coordinate.get_y() + direction.get_y()};
}
void Robot::kill() {_alive = false;}
bool Robot::is_alive() {return _alive;}
