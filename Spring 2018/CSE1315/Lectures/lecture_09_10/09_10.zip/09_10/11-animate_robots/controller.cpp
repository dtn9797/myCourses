#include "controller.h"
#include "globals.h"
#include "grid.h"
#include "view.h"
#include <iostream>
#include <cstdlib>

/**
 * Controller manages the model and view
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
View Controller::get_view() {return _view;}

void Controller::cli() {
    _view.print_banner();
    string cmd = "x";
    while (cmd[0] != '0' && _grid.get_player().is_alive()) {
        _view.print_grid();
        cout << _grid.get_player().get_coordinate().to_string() << " Command? ";
        cin >> cmd;
        execute_cmd(cmd);
        _grid.animate_robots();
        _grid.detect_collisions();
    }
    _view.print_grid();
};
void Controller::execute_cmd(string cmd) {
        if (cmd[0] == '1') { _grid.move_player(Coordinate(-1, 1)); }
        if (cmd[0] == '2') { _grid.move_player(Coordinate( 0, 1)); }
        if (cmd[0] == '3') { _grid.move_player(Coordinate( 1, 1)); }
        if (cmd[0] == '4') { _grid.move_player(Coordinate(-1, 0)); }
        if (cmd[0] == '5') { _grid.move_player(Coordinate( 0, 0)); }
        if (cmd[0] == '6') { _grid.move_player(Coordinate( 1, 0)); }
        if (cmd[0] == '7') { _grid.move_player(Coordinate(-1,-1)); }
        if (cmd[0] == '8') { _grid.move_player(Coordinate( 0,-1)); }
        if (cmd[0] == '9') { _grid.move_player(Coordinate( 1,-1)); }
};
