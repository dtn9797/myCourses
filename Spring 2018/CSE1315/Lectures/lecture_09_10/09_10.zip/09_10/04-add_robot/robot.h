#ifndef ROBOT
#define ROBOT 2016

#include "globals.h"
#include "coordinate.h"
#include <string>

using namespace std;

/**
 * Robot models a generic autonomous or remote controlled machine.
 *
 * @author      George F. Rice
 * @version     1.0 alpha
 * @since       1.0
 */
 
class Robot {
  public:
    Robot(string robot_id, Coordinate coordinate) : 
      _robot_id{robot_id}, _coordinate{coordinate} { }
    Robot() : Robot("Robot"+std::to_string(generateID()), Coordinate()) { }

    string get_robot_id( );
    Coordinate get_coordinate( );
    string to_string( );

  private:
    string _robot_id; // "Name" of the robot to display on-screen
    Coordinate _coordinate;  // location of robot on an X-Y grid

    int generateID() {      // generate unique ID for each robot
      static int s_robot_id = 0;
      return ++s_robot_id;
    }
};
#endif
