#include "complex.h"
#include <iostream>
using namespace std;

int main() {
  Complex c{4, 5};
  cout << c.magnitude() << endl;
}
