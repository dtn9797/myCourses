// For demo purposes only - a full complex number template
//   is available in the standard library!
// See http://www.cplusplus.com/reference/complex/complex/

class Complex {
    int _x;
    int _y;
  public:
    Complex(int x, int y);
    Complex();
    double magnitude();
};
