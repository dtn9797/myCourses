#ifndef _ACME_ROBOT
#define _ACME_ROBOT

class Acme_robot {
  public:
    virtual void move(int speed, int direction) = 0;
};
#endif
