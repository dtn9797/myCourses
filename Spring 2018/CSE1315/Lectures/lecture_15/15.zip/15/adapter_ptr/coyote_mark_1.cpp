#include "coyote_robot.h"
#include "coyote_mark_1.h"
#include <iostream>

void Coyote_robot_mark_1::turn(int direction) {
    std::cout << "Turning to heading " << direction << std::endl;
}

void Coyote_robot_mark_1::move(int speed) {
    std::cout << "Moving at " << speed << " kph" << std::endl;
}
