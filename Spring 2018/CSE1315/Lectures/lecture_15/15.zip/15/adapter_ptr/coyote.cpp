#include "coyote_robot.h"
#include "coyote_controller.h"
#include "coyote_mark_1.h"

int main() {
  Coyote_robot *robot = new Coyote_robot_mark_1{};
  Coyote_controller controller{robot};
  controller.control();
}
