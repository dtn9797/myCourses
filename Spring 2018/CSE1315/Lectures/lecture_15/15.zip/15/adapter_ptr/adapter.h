#ifndef _ADAPTER_H
#define _ADAPTER_H
#include "acme_robot.h"
#include "coyote_robot.h"

class Adapter : public Acme_robot {
  public:
    Adapter(Coyote_robot* robot);
    virtual void move(int speed, int direction) override;
  private:
    Coyote_robot* _robot;
};
#endif
