#ifndef _COYOTE_ROBOT
#define _COYOTE_ROBOT

class Coyote_robot {
  public:
    virtual void turn(int direction) = 0;
    virtual void move(int speed) = 0;
};
#endif
