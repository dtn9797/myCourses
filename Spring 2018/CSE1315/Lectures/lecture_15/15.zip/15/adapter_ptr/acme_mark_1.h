#ifndef _ACME_MARK_1_H
#define _ACME_MARK_1_H
#include "acme_robot.h"

class Acme_robot_mark_1 : public Acme_robot {
  public:
    virtual void move(int speed, int direction) override;
};
#endif
