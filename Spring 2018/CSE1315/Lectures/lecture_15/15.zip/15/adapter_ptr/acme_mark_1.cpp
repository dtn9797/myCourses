#include "acme_robot.h"
#include "acme_mark_1.h"
#include <iostream>

void Acme_robot_mark_1::move(int speed, int direction) {
    std::cout << "Moving at " << speed << " kph, direction " 
                              << direction << std::endl;
}
