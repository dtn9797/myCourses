#ifndef _COYOTE_MARK_1_H
#define _COYOTE_MARK_1_H
#include "coyote_robot.h"

class Coyote_robot_mark_1 : public Coyote_robot {
  public:
    virtual void turn(int direction) override;
    virtual void move(int speed) override;
};
#endif
