#include "adapter.h"

Adapter::Adapter(Coyote_robot* robot) : _robot{robot} { }

void Adapter::move(int speed, int direction) {
  _robot->turn(direction);
  _robot->move(speed);  // move S at 10 kph
}
