#include "coyote_robot.h"

class Coyote_controller {
  public:
    Coyote_controller(Coyote_robot* robot);
    void control();
  private:
    Coyote_robot* _robot;
};

