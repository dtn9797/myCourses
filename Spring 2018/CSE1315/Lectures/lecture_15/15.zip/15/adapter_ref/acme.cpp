#include "acme_robot.h"
#include "acme_controller.h"
#include "acme_mark_1.h"

int main() {
  Acme_robot_mark_1 robot{};
  Acme_controller controller{robot};
  controller.control();
}
