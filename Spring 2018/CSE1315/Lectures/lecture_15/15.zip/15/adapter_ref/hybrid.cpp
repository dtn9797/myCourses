#include "coyote_robot.h"
#include "coyote_mark_1.h"
#include "acme_controller.h"
#include "adapter.h"

int main() {
  Coyote_robot_mark_1 robot{};
  Adapter adapter{robot};
  Acme_controller controller{adapter};
  controller.control();
}
