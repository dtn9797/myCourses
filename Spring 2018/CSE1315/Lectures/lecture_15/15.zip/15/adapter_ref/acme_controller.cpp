#include "acme_controller.h"
#include <iostream>

Acme_controller::Acme_controller(Acme_robot& robot) : _robot{robot} { }

void Acme_controller::control() {
  std::cout << "Acme: Commanding move(10, 180)" << std::endl;
  _robot.move(10, 180); // move S at 10 kph
}
