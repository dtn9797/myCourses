#include "acme_robot.h"

class Acme_controller {
  public:
    Acme_controller(Acme_robot& robot);
    void control();
  private:
    Acme_robot& _robot;
};
