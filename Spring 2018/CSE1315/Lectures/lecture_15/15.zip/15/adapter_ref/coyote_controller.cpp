#include "coyote_controller.h"
#include <iostream>

Coyote_controller::Coyote_controller(Coyote_robot& robot) : _robot{robot} { }

void Coyote_controller::control() {
  std::cout << "Coyote: Commanding turn(180), then move(10)" << std::endl;
  _robot.turn(180);
  _robot.move(10);  // move S at 10 kph
}
